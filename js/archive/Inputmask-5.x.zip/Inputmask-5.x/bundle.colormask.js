import "./bundle";
import Colormask from "./lib/extensions/colorMask";
export default Colormask;

